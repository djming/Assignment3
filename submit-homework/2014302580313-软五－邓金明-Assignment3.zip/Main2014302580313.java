import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

import javax.swing.text.html.ListView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.mysql.jdbc.PreparedStatement;

public class Main2014302580313 {
	static JSoupUtils2014302580313 jsu;
	static SQLUtils2014302580313 su;
	static List<String> links;

	public static void main(String[] args) {
		su = new SQLUtils2014302580313();
		jsu = new JSoupUtils2014302580313();
		links = jsu.getUrls();
		if (jsu.hasConnected()) {
			SingleSpider2014302580313 ss = new SingleSpider2014302580313(links);
			System.out.println("SingleSpider start!");
			ss.run();

			MultiplySpider2014302580313 mSpider = new MultiplySpider2014302580313(links);
			System.out.println("MutiplySpider start!");
			mSpider.run();

		} else {
			System.out.println("Connected failed.Please check your network.");
		}
		
	}

	public static class MultiplySpider2014302580313 {
		static List<String> links;
		static int mI = 0;
		static int mTime = 0;
		static long startTime;
		static int finishedThread = 0;
		List<Thread> tList;

		public MultiplySpider2014302580313(List<String> links) {
			this.links = links;
		}

		public void run() {
			tList = new ArrayList<>();
			startTime = System.currentTimeMillis();
			MThread2014302580313 mThread = new MThread2014302580313();
			// 十个线程一齐抓取
			for (int i = 0; i < 10; i++) {
				Thread thread = new Thread(mThread);
				tList.add(thread);
				thread.start();

			}
			for (Thread t : tList) {
				try {
					t.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			long endTime = System.currentTimeMillis();
			printTime(startTime, endTime);
		}

		static class MThread2014302580313 implements Runnable {

			public synchronized int getMI() {
				mI++;
				return mI - 1;
			}

			public synchronized void finished() {
				finishedThread++;
			}

			@Override
			public void run() {
				int current = 0;
				while ((current = getMI()) < links.size()) {
					int times = 0;
					Techer2014302580313 techer = jsu.readInfo(links.get(current));

					while (!su.mInsert(techer) && times < 3) {
						times++;
						System.out.println("Insert failed.Try again.");
					}
					System.out.println("Insert succeed!" + current + " has inserted.");
				}
				finished();
			}
		}
	}

	// 单线程爬虫
	public static class SingleSpider2014302580313 {
		List<String> links;
		long startTime;

		public SingleSpider2014302580313(List<String> links) {
			this.links = links;
		}

		public void run() {
			startTime = System.currentTimeMillis();
			int i = 0;
			while (i < links.size()) {
				Techer2014302580313 techer = jsu.readInfo(links.get(i));
				if (su.sInsert(techer)) {
					i++;
					System.out.println("Insert succeed." + i + " has inserted.");
				} else {
					System.out.println("=============inser failed!===========");
					return;
				}
			}
			long endTime = System.currentTimeMillis();
			printTime(startTime, endTime);
		}
	}

	public static class Techer2014302580313 {
		private String name;
		private String email;
		private String telphone;
		private String direction;
		private String breif;

		public Techer2014302580313(String name, String email, String telphone, String direction,
				String breif) {
			this.name = name;
			this.email = email;
			this.telphone = telphone;
			this.direction = direction;
			this.breif = breif;
		}

		public String getBreif() {
			return breif;
		}

		public String getDirection() {
			return direction;
		}

		public String getEmail() {
			return email;
		}

		public String getName() {
			return name;
		}

		public String getTelphone() {
			return telphone;
		}
	}

	public static class JSoupUtils2014302580313 {
		private List<String> links;
		boolean connected = false;

		public JSoupUtils2014302580313() {
			links = new ArrayList<>();
			int connTime = 0;
			while (!connected && connTime < 3) {
				try {
					System.out.println("Getting links from main page...");
					Document doc = Jsoup.connect("https://www.wpi.edu/academics/cs/research-interests.html")
							.timeout(5000).get();
					Elements url = doc.select("div.half").select("a[href]");
					System.out.println("Got " + url.size() + " links");
					for (int i = 0; i < url.size(); i++) {
						links.add(url.get(i).attr("href"));
						System.out.println("Having added " + (i + 1) + " teacher's personal pages.");
					}
					System.out.println("All links got!");
					connected = true;
				} catch (IOException e) {
					System.out.println(e.getMessage());
					System.out.println("Connect failed!Try again.");
					connTime++;
				}
			}
		}

		public List<String> getUrls() {
			return this.links;
		}

		public boolean hasConnected() {
			return this.connected;
		}

		public Techer2014302580313 readInfo(String url) {
			Techer2014302580313 t;
			String telphone = "";
			Document document;
			boolean conn = false;
			int connTime = 0;
			while (!conn && connTime < 3) {
				try {
					document = Jsoup.connect(url).timeout(5000).get();
					conn = true;
					if (conn) {
						// name
						Element name = document.select("#content>h2").first();
						String n = name.text();
						// email
						Element email = document.select("#contactinfo>p>a[href]").first();
						String e = email.text();
						// tel
						Element tel = document.select("#contactinfo>p").first();
						Pattern pattern = Pattern.compile("Phone:..(\\d{1}).(\\d{3}).(\\d{3}).(\\d{4})");
						Matcher m = pattern.matcher(tel.text());
						if (m.find()) {
							telphone = m.group(1) + m.group(2) + m.group(3) + m.group(4);
						}
						// direction
						Elements direction = document.select("#twocol>.col>ul>li");
						StringBuilder drcn = new StringBuilder();
						drcn.append("");
						for (int i = 0; i < direction.size(); i++) {
							drcn.append((i + 1) + "." + direction.get(i).text() + "\r\n");
						}
						String d = drcn.toString();
						// breif
						Element b = document.select("#content>p").first();
						String breif = "No self-description";

						if (b != null) {
							breif = b.text();
						}
						t = new Techer2014302580313(n, e, telphone, d, breif);
						return t;
					}
				} catch (IOException e) {
					// e.printStackTrace();
					System.out.println("Get teacher info failed!Try again!");
					connTime++;
				}
			}

			return new Techer2014302580313(null, null, null, null, null);
		}

	}

	public static class SQLUtils2014302580313 {
		Statement stmt;
		Connection conn;

		public SQLUtils2014302580313() {
			try {

				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignmentDB", "levi", "admin");
				stmt = conn.createStatement();
				System.out.println("Creating MySQL Database tables;");
				stmt.execute("CREATE TABLE IF NOT EXISTS s_teacher(name VARCHAR(255) DEFAULT \"\","
						+ "email VARCHAR(255) DEFAULT \"\", "
						+ "telphone VARCHAR(255) DEFAULT \"\", direction TEXT , breif TEXT);");
				System.out.println("Table for SingleSpider is created;");
		
				stmt.execute("CREATE TABLE IF NOT EXISTS m_teacher(name VARCHAR(255) DEFAULT \"\","
						+ "email VARCHAR(255) DEFAULT \"\", "
						+ "telphone VARCHAR(255) DEFAULT \"\", direction TEXT , breif TEXT);");
				
				System.out.println("Table for MultiplySpider is created;");

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		// 插入数据
		public boolean sInsert(Techer2014302580313 t) {
			String sql = "INSERT INTO s_teacher(name,email,telphone,direction,breif) VALUES(?,?,?,?,?);";
			int i = 0;
			try {
				PreparedStatement pstmt = (PreparedStatement) conn.prepareStatement(sql);
				pstmt.setObject(1, t.getName());
				pstmt.setObject(2, t.getEmail());
				pstmt.setObject(3, t.getTelphone());
				pstmt.setObject(4, t.getDirection());
				pstmt.setObject(5, t.getBreif());
				i = pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return i > 0 ? true : false;
		}

		// 插入数据
		public boolean mInsert(Techer2014302580313 t) {
			String sql = "INSERT INTO m_teacher(name,email,telphone,direction,breif) VALUES(?,?,?,?,?);";
			int i = 0;
			try {
				PreparedStatement pstmt = (PreparedStatement) conn.prepareStatement(sql);
				pstmt.setObject(1, t.getName());
				pstmt.setObject(2, t.getEmail());
				pstmt.setObject(3, t.getTelphone());
				pstmt.setObject(4, t.getDirection());
				pstmt.setObject(5, t.getBreif());
				i = pstmt.executeUpdate();
			} catch (SQLException e) {
				System.out.println("Insert failed!\r\nCasued by " + e.getMessage());
			}
			return i > 0 ? true : false;
		}
	}

	public static void printTime(long startTime, long endTime) {
		int time = (int) (endTime - startTime);
		int ms = 00;
		int s = 00;
		int min = 00;
		if (time > 1000) {
			ms = time % 1000;
			s = (time - ms) / 1000;
		}
		if (s > 60) {
			min = s / 60;
			s = s % 60;
		}
		System.out.println(min + " minutes " + s + " second " + ms + " ms has used!");
	}
}
